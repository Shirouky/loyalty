import Vue from 'vue'
import App from './App.vue'
import router from './router'
import axios from 'axios'
import VueAxios from 'vue-axios'
import { store } from './store'
import VueQrcode from '@chenfengyuan/vue-qrcode';
import { QrcodeStream } from 'vue-qrcode-reader'
import { library } from '@fortawesome/fontawesome-svg-core'
import { faTrash, faComments, faCogs, faHome, faBookmark, faArrowRight, faArrowLeft, faPenToSquare, faCaretRight, faEye, faPlus, faTimes, faSearch, faEllipsis, faCaretUp, faCaretDown, faMagnifyingGlass, faShare } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome'

library.add(faTrash, faComments, faCogs, faHome, faBookmark, faEye, faArrowLeft, faArrowRight, faPenToSquare, faCaretRight, faPlus, faTimes, faSearch, faEllipsis, faCaretDown, faMagnifyingGlass, faCaretUp, faShare)
// eslint-disable-next-line
Vue.component('qrcode-stream', QrcodeStream)
Vue.component('qrcode-code', VueQrcode);
Vue.component('fa-f', FontAwesomeIcon)
Vue.use(VueAxios, axios);
Vue.config.productionTip = false


new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')

